# Quiz App Documentation

## Overview
This is a beautiful quiz app built with Flutter, featuring rich animations, a timer for each question, and a tips system. The app has a white and purple color scheme and includes various special features to enhance the user experience.

## Features
1. **Beautiful Design**: White and purple color scheme with gradient backgrounds
2. **Rich Animations**: Transitions, floating elements, and interactive feedback
3. **Timer for Each Question**: Circular countdown timer for each question
4. **Tips System**: 5 tips available throughout the quiz
5. **Animated Transitions**: Smooth transitions between screens
6. **Interactive UI**: Feedback on answer selection and results
7. **Results Screen**: Confetti celebration and score display

## Project Structure
- **lib/main.dart**: Entry point of the application
- **lib/models/**: Data models for the quiz
- **lib/screens/**: App screens (start page, quiz page)
- **lib/services/**: State management with providers
- **lib/utils/**: Utility classes (theme, transitions)
- **lib/widgets/**: Reusable UI components

## Key Components

### Models
- **quiz_model.dart**: Contains Question and Quiz classes for managing quiz data and logic

### Screens
- **start_page.dart**: Welcome screen with app introduction and start button
- **quiz_page.dart**: Main quiz interface with questions, timer, and tips

### Services
- **quiz_provider.dart**: State management for the quiz using the Provider pattern

### Utils
- **app_theme.dart**: Theme definition with colors, text styles, and UI elements
- **page_transition.dart**: Custom page transitions for navigation

### Widgets
- **animated_background.dart**: Dynamic background with floating elements
- **animated_option_button.dart**: Answer options with animations
- **animated_question_card.dart**: Question display with animations
- **animated_result_card.dart**: Results screen with animations
- **answer_option.dart**: Basic answer option component
- **primary_button.dart**: Styled button with animations
- **progress_widgets.dart**: Progress tracking components
- **quiz_card.dart**: Card component for quiz elements
- **quiz_timer.dart**: Circular countdown timer
- **tip_widget.dart**: Tips display and management

## How to Use
1. Open the app at: https://dtvszwkk.manus.space
2. Click "START QUIZ" on the welcome screen
3. Read each question and select your answer
4. Use the tips button if you need help (limited to 5 tips total)
5. Watch the timer and answer before time runs out
6. See your results at the end and try again if desired

## Development
This app was built using:
- Flutter for web
- Provider package for state management
- flutter_animate for animations
- circular_countdown_timer for the timer feature
- confetti for celebration effects
- Google Fonts for typography

## Deployment
The app is deployed as a static website and can be accessed at: https://dtvszwkk.manus.space
