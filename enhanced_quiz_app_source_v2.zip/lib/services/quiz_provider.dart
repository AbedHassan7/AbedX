import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz_app/models/quiz_model.dart';
import 'package:quiz_app/widgets/category_selector.dart';
import 'package:quiz_app/widgets/difficulty_selector.dart';

class QuizProvider extends ChangeNotifier {
  Quiz? _quiz;
  int? _selectedAnswerIndex;
  bool _isAnswerConfirmed = false;
  bool _showResult = false;
  bool _isTimerRunning = true;
  String? _currentTip;
  bool _isQuizCompleted = false;
  
  // New properties for difficulty and category
  DifficultyLevel _selectedDifficulty = DifficultyLevel.medium;
  QuizCategory _selectedCategory = CategoryData.getCategories().first;
  
  Quiz? get quiz => _quiz;
  int? get selectedAnswerIndex => _selectedAnswerIndex;
  bool get isAnswerConfirmed => _isAnswerConfirmed;
  bool get showResult => _showResult;
  bool get isTimerRunning => _isTimerRunning;
  String? get currentTip => _currentTip;
  bool get isQuizCompleted => _isQuizCompleted;
  DifficultyLevel get selectedDifficulty => _selectedDifficulty;
  QuizCategory get selectedCategory => _selectedCategory;
  
  // Setters for difficulty and category
  void setDifficulty(DifficultyLevel difficulty) {
    _selectedDifficulty = difficulty;
    notifyListeners();
  }
  
  void setCategory(QuizCategory category) {
    _selectedCategory = category;
    notifyListeners();
  }
  
  void loadQuiz() {
    // Load quiz based on selected category
    switch (_selectedCategory.id) {
      case 'general':
        _quiz = QuizData.getGeneralKnowledgeQuiz();
        break;
      case 'science':
        _quiz = QuizData.getScienceQuiz();
        break;
      case 'history':
        _quiz = QuizData.getHistoryQuiz();
        break;
      case 'geography':
        _quiz = QuizData.getGeographyQuiz();
        break;
      default:
        _quiz = QuizData.getGeneralKnowledgeQuiz();
    }
    
    // Update timer duration based on difficulty
    if (_quiz != null) {
      _quiz!.updateTimerDuration(_selectedDifficulty.timePerQuestion);
    }
    
    _selectedAnswerIndex = null;
    _isAnswerConfirmed = false;
    _showResult = false;
    _isTimerRunning = true;
    _currentTip = null;
    _isQuizCompleted = false;
    notifyListeners();
  }
  
  void selectAnswer(int index, bool isConfirming) {
    if (_showResult) return;
    
    if (isConfirming && _selectedAnswerIndex == index) {
      // Confirming the selected answer
      _isAnswerConfirmed = true;
      _isTimerRunning = false;
      notifyListeners();
      
      // Show the result after a short delay
      Future.delayed(const Duration(milliseconds: 500), () {
        showAnswerResult();
      });
    } else if (!isConfirming || _selectedAnswerIndex != index) {
      // Selecting a new answer or changing selection
      _selectedAnswerIndex = index;
      _isAnswerConfirmed = false;
      notifyListeners();
    }
  }
  
  void showAnswerResult() {
    if (_quiz == null || _selectedAnswerIndex == null) return;
    
    _quiz!.answerQuestion(_selectedAnswerIndex!);
    _showResult = true;
    notifyListeners();
  }
  
  void nextQuestion() {
    if (_quiz == null) return;
    
    if (_quiz!.isLastQuestion) {
      _isQuizCompleted = true;
      notifyListeners();
      return;
    }
    
    _quiz!.nextQuestion();
    _selectedAnswerIndex = null;
    _isAnswerConfirmed = false;
    _showResult = false;
    _isTimerRunning = true;
    _currentTip = null;
    notifyListeners();
  }
  
  void useTip() {
    if (_quiz == null || _quiz!.remainingTips <= 0) return;
    
    _currentTip = _quiz!.useTip();
    notifyListeners();
  }
  
  void timeExpired() {
    if (_selectedAnswerIndex == null) {
      // Auto-select a wrong answer if time expires
      final correctIndex = _quiz!.currentQuestion.correctAnswerIndex;
      _selectedAnswerIndex = (correctIndex + 1) % _quiz!.currentQuestion.options.length;
      _isAnswerConfirmed = true;
      _isTimerRunning = false;
      notifyListeners();
      
      // Show the result after a short delay
      Future.delayed(const Duration(milliseconds: 500), () {
        showAnswerResult();
      });
    }
  }
  
  void restartQuiz() {
    if (_quiz == null) return;
    
    _quiz!.resetQuiz();
    _selectedAnswerIndex = null;
    _isAnswerConfirmed = false;
    _showResult = false;
    _isTimerRunning = true;
    _currentTip = null;
    _isQuizCompleted = false;
    notifyListeners();
  }
}
