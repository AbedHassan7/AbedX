import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz_app/models/quiz_model.dart';
import 'package:quiz_app/screens/results_page.dart';
import 'package:quiz_app/services/quiz_provider.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:quiz_app/widgets/answer_option.dart';
import 'package:quiz_app/widgets/primary_button.dart';
import 'package:quiz_app/widgets/progress_widgets.dart';
import 'package:quiz_app/widgets/quiz_card.dart';
import 'package:quiz_app/widgets/quiz_timer.dart';
import 'package:quiz_app/widgets/tip_widget.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:confetti/confetti.dart';
import 'package:quiz_app/widgets/difficulty_selector.dart';

class QuizPage extends StatefulWidget {
  const QuizPage({Key? key}) : super(key: key);

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final CountDownController _timerController = CountDownController();
  late ConfettiController _confettiController;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 3));
    
    // Initialize the quiz when the page loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<QuizProvider>(context, listen: false).loadQuiz();
    });
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<QuizProvider>(
      builder: (context, quizProvider, child) {
        if (quizProvider.quiz == null) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (quizProvider.isQuizCompleted) {
          return ResultsPage(quiz: quizProvider.quiz!);
        }

        return Scaffold(
          backgroundColor: AppTheme.backgroundColor,
          appBar: AppBar(
            title: Text(quizProvider.quiz!.title),
            backgroundColor: AppTheme.primaryColor,
            elevation: 0,
            actions: [
              // Display current difficulty level in the app bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: quizProvider.selectedDifficulty.color.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: quizProvider.selectedDifficulty.color,
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          quizProvider.selectedDifficulty.icon,
                          color: quizProvider.selectedDifficulty.color,
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          quizProvider.selectedDifficulty.name,
                          style: TextStyle(
                            color: quizProvider.selectedDifficulty.color,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                // Category indicator
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  color: _getCategoryColor(quizProvider.selectedCategory.id).withOpacity(0.1),
                  child: Row(
                    children: [
                      Icon(
                        _getCategoryIcon(quizProvider.selectedCategory.id),
                        color: _getCategoryColor(quizProvider.selectedCategory.id),
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Category: ${quizProvider.selectedCategory.name}',
                        style: TextStyle(
                          color: _getCategoryColor(quizProvider.selectedCategory.id),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ProgressBar(
                    currentQuestion: quizProvider.quiz!.currentQuestionIndex + 1,
                    totalQuestions: quizProvider.quiz!.totalQuestions,
                    progress: quizProvider.quiz!.progress,
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Time Remaining:',
                              style: AppTheme.bodyStyle.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            QuizTimer(
                              // Use the timer duration from the quiz which is set based on difficulty
                              duration: quizProvider.quiz!.timePerQuestionInSeconds,
                              onComplete: () => quizProvider.timeExpired(),
                              controller: _timerController,
                              isRunning: quizProvider.isTimerRunning,
                              // Pass difficulty color to the timer for visual indication
                              difficultyColor: quizProvider.selectedDifficulty.color,
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        QuizCard(
                          title: 'Question ${quizProvider.quiz!.currentQuestionIndex + 1}',
                          child: Text(
                            quizProvider.quiz!.currentQuestion.text,
                            style: AppTheme.subheadingStyle,
                          ),
                        ),
                        const SizedBox(height: 16),
                        ...List.generate(
                          quizProvider.quiz!.currentQuestion.options.length,
                          (index) => AnswerOption(
                            text: quizProvider.quiz!.currentQuestion.options[index],
                            isSelected: quizProvider.selectedAnswerIndex == index,
                            isConfirmed: quizProvider.isAnswerConfirmed && quizProvider.selectedAnswerIndex == index,
                            isCorrect: quizProvider.quiz!.currentQuestion.correctAnswerIndex == index,
                            showResult: quizProvider.showResult,
                            onTap: (isConfirming) {
                              quizProvider.selectAnswer(index, isConfirming);
                            },
                            index: index,
                          ),
                        ),
                        const SizedBox(height: 24),
                        if (quizProvider.showResult) ...[
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                  ? AppTheme.correctAnswerColor.withOpacity(0.1)
                                  : AppTheme.wrongAnswerColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                    ? AppTheme.correctAnswerColor
                                    : AppTheme.wrongAnswerColor,
                                width: 1,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                          ? Icons.check_circle
                                          : Icons.cancel,
                                      color: quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                          ? AppTheme.correctAnswerColor
                                          : AppTheme.wrongAnswerColor,
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                          ? 'Correct!'
                                          : 'Incorrect!',
                                      style: AppTheme.subheadingStyle.copyWith(
                                        color: quizProvider.quiz!.currentQuestion.isCorrectAnswer(quizProvider.selectedAnswerIndex!)
                                            ? AppTheme.correctAnswerColor
                                            : AppTheme.wrongAnswerColor,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                if (quizProvider.quiz!.currentQuestion.explanation != null)
                                  Text(
                                    quizProvider.quiz!.currentQuestion.explanation!,
                                    style: AppTheme.bodyStyle,
                                  ),
                              ],
                            ),
                          )
                          .animate()
                          .fadeIn(duration: 300.ms)
                          .slideY(begin: 0.2, end: 0, duration: 300.ms, curve: Curves.easeOutQuad),
                          const SizedBox(height: 24),
                          PrimaryButton(
                            text: quizProvider.quiz!.isLastQuestion ? 'See Results' : 'Next Question',
                            onPressed: () {
                              quizProvider.nextQuestion();
                              if (!quizProvider.isQuizCompleted) {
                                _timerController.restart();
                              } else {
                                _confettiController.play();
                              }
                            },
                            icon: quizProvider.quiz!.isLastQuestion ? Icons.emoji_events : Icons.arrow_forward,
                          ),
                        ] else ...[
                          const SizedBox(height: 16),
                          TipWidget(
                            totalTips: quizProvider.quiz!.totalTips,
                            remainingTips: quizProvider.quiz!.remainingTips,
                            onUseTip: () => quizProvider.useTip(),
                            currentTip: quizProvider.currentTip,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  
  // Helper method to get category color
  Color _getCategoryColor(String categoryId) {
    switch (categoryId) {
      case 'general':
        return Colors.blue;
      case 'science':
        return Colors.green;
      case 'history':
        return Colors.amber;
      case 'geography':
        return Colors.purple;
      default:
        return AppTheme.primaryColor;
    }
  }
  
  // Helper method to get category icon
  IconData _getCategoryIcon(String categoryId) {
    switch (categoryId) {
      case 'general':
        return Icons.lightbulb;
      case 'science':
        return Icons.science;
      case 'history':
        return Icons.history;
      case 'geography':
        return Icons.public;
      default:
        return Icons.quiz;
    }
  }
}
