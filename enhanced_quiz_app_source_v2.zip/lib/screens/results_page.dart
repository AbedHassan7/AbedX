import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz_app/models/quiz_model.dart';
import 'package:quiz_app/services/quiz_provider.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:quiz_app/widgets/primary_button.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:confetti/confetti.dart';
import 'dart:math' as math;

class ResultsPage extends StatefulWidget {
  final Quiz quiz;
  
  const ResultsPage({
    Key? key,
    required this.quiz,
  }) : super(key: key);

  @override
  State<ResultsPage> createState() => _ResultsPageState();
}

class _ResultsPageState extends State<ResultsPage> {
  late ConfettiController _confettiController;
  int _selectedQuestionIndex = -1;
  
  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 5));
    _confettiController.play();
  }
  
  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    final score = widget.quiz.score;
    final total = widget.quiz.totalQuestions;
    final percentage = widget.quiz.getScorePercentage();
    
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Quiz Results'),
        backgroundColor: AppTheme.primaryColor,
        elevation: 0,
      ),
      body: Stack(
        children: [
          // Confetti effect
          Align(
            alignment: Alignment.topCenter,
            child: ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              particleDrag: 0.05,
              emissionFrequency: 0.05,
              numberOfParticles: 20,
              gravity: 0.1,
              colors: const [
                Colors.purple,
                Colors.blue,
                Colors.pink,
                Colors.orange,
                Colors.green,
              ],
            ),
          ),
          
          // Main content
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Score circle
                _buildScoreCircle(score, total, percentage),
                
                const SizedBox(height: 30),
                
                // Performance stats
                _buildPerformanceStats(score, total, percentage),
                
                const SizedBox(height: 30),
                
                // Question-by-question results
                _buildQuestionResults(),
                
                const SizedBox(height: 30),
                
                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: PrimaryButton(
                        text: 'Try Again',
                        onPressed: () {
                          final quizProvider = Provider.of<QuizProvider>(context, listen: false);
                          quizProvider.restartQuiz();
                        },
                        icon: Icons.replay,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: 16),
                
                TextButton.icon(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(Icons.home),
                  label: const Text('Back to Home'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildScoreCircle(int score, int total, double percentage) {
    final color = _getScoreColor(percentage);
    final grade = _getGrade(percentage);
    
    return Container(
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            color.withOpacity(0.7),
            color,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Percentage circle
          SizedBox(
            width: 180,
            height: 180,
            child: CustomPaint(
              painter: CircleProgressPainter(
                percentage: percentage / 100,
                color: Colors.white,
                strokeWidth: 8,
              ),
            ),
          ),
          
          // Score text
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$score/$total',
                style: AppTheme.headingStyle.copyWith(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '${percentage.toInt()}%',
                style: AppTheme.bodyStyle.copyWith(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
              const SizedBox(height: 5),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Grade: $grade',
                  style: AppTheme.bodyStyle.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    )
    .animate()
    .scale(
      begin: const Offset(0.5, 0.5),
      end: const Offset(1, 1),
      duration: 800.ms,
      curve: Curves.elasticOut,
    );
  }
  
  Widget _buildPerformanceStats(int score, int total, double percentage) {
    final timeTaken = "2:45"; // This would be calculated from actual quiz time
    final avgTimePerQuestion = "10.3s"; // This would be calculated from actual quiz time
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Performance Statistics',
            style: AppTheme.subheadingStyle.copyWith(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          _buildStatRow(
            icon: Icons.check_circle,
            label: 'Correct Answers',
            value: '$score out of $total',
            color: AppTheme.correctAnswerColor,
          ),
          _buildStatRow(
            icon: Icons.cancel,
            label: 'Incorrect Answers',
            value: '${total - score} out of $total',
            color: AppTheme.wrongAnswerColor,
          ),
          _buildStatRow(
            icon: Icons.timer,
            label: 'Total Time Taken',
            value: timeTaken,
            color: Colors.blue,
          ),
          _buildStatRow(
            icon: Icons.speed,
            label: 'Avg. Time per Question',
            value: avgTimePerQuestion,
            color: Colors.orange,
          ),
          _buildStatRow(
            icon: Icons.lightbulb,
            label: 'Tips Used',
            value: '${5 - widget.quiz.remainingTips} out of 5',
            color: Colors.amber,
          ),
        ],
      ),
    )
    .animate()
    .fadeIn(delay: 300.ms, duration: 500.ms)
    .slideY(
      begin: 0.3,
      end: 0,
      delay: 300.ms,
      duration: 500.ms,
      curve: Curves.easeOutQuad,
    );
  }
  
  Widget _buildStatRow({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              icon,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              label,
              style: AppTheme.bodyStyle.copyWith(
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Text(
            value,
            style: AppTheme.bodyStyle.copyWith(
              fontWeight: FontWeight.bold,
              color: AppTheme.primaryColor,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildQuestionResults() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Question-by-Question Results',
          style: AppTheme.subheadingStyle.copyWith(
            color: AppTheme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: widget.quiz.questions.length,
          itemBuilder: (context, index) {
            final question = widget.quiz.questions[index];
            final isCorrect = index < widget.quiz.currentQuestionIndex + 1
                ? (index == widget.quiz.currentQuestionIndex
                    ? widget.quiz.score > 0
                    : true)
                : false;
            
            return GestureDetector(
              onTap: () {
                setState(() {
                  _selectedQuestionIndex = _selectedQuestionIndex == index ? -1 : index;
                });
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isCorrect ? AppTheme.correctAnswerColor : AppTheme.wrongAnswerColor,
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 5,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Question header
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isCorrect
                            ? AppTheme.correctAnswerColor.withOpacity(0.1)
                            : AppTheme.wrongAnswerColor.withOpacity(0.1),
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 30,
                            height: 30,
                            decoration: BoxDecoration(
                              color: isCorrect
                                  ? AppTheme.correctAnswerColor
                                  : AppTheme.wrongAnswerColor,
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Text(
                                '${index + 1}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              question.text,
                              style: AppTheme.bodyStyle.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          Icon(
                            isCorrect ? Icons.check_circle : Icons.cancel,
                            color: isCorrect
                                ? AppTheme.correctAnswerColor
                                : AppTheme.wrongAnswerColor,
                          ),
                        ],
                      ),
                    ),
                    
                    // Question details (expanded when selected)
                    if (_selectedQuestionIndex == index)
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Answer Options:',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            ...List.generate(
                              question.options.length,
                              (optionIndex) => Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 24,
                                      height: 24,
                                      decoration: BoxDecoration(
                                        color: question.correctAnswerIndex == optionIndex
                                            ? AppTheme.correctAnswerColor
                                            : Colors.transparent,
                                        border: Border.all(
                                          color: question.correctAnswerIndex == optionIndex
                                              ? AppTheme.correctAnswerColor
                                              : Colors.grey,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: question.correctAnswerIndex == optionIndex
                                          ? const Icon(
                                              Icons.check,
                                              color: Colors.white,
                                              size: 16,
                                            )
                                          : null,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        question.options[optionIndex],
                                        style: TextStyle(
                                          color: question.correctAnswerIndex == optionIndex
                                              ? AppTheme.correctAnswerColor
                                              : null,
                                          fontWeight: question.correctAnswerIndex == optionIndex
                                              ? FontWeight.bold
                                              : null,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            if (question.explanation != null) ...[
                              const SizedBox(height: 12),
                              const Text(
                                'Explanation:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(question.explanation!),
                            ],
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            )
            .animate()
            .fadeIn(delay: (50 * index).ms, duration: 300.ms)
            .slideX(
              begin: 0.1,
              end: 0,
              delay: (50 * index).ms,
              duration: 300.ms,
              curve: Curves.easeOutQuad,
            );
          },
        ),
      ],
    );
  }
  
  Color _getScoreColor(double percentage) {
    if (percentage >= 90) {
      return Colors.green;
    } else if (percentage >= 70) {
      return Colors.blue;
    } else if (percentage >= 50) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }
  
  String _getGrade(double percentage) {
    if (percentage >= 90) {
      return 'A';
    } else if (percentage >= 80) {
      return 'B';
    } else if (percentage >= 70) {
      return 'C';
    } else if (percentage >= 60) {
      return 'D';
    } else {
      return 'F';
    }
  }
}

class CircleProgressPainter extends CustomPainter {
  final double percentage;
  final Color color;
  final double strokeWidth;
  
  CircleProgressPainter({
    required this.percentage,
    required this.color,
    this.strokeWidth = 10,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) / 2 - strokeWidth / 2;
    
    // Draw background circle
    final backgroundPaint = Paint()
      ..color = color.withOpacity(0.2)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    
    canvas.drawCircle(center, radius, backgroundPaint);
    
    // Draw progress arc
    final progressPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    
    final sweepAngle = 2 * math.pi * percentage;
    
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2, // Start from top
      sweepAngle,
      false,
      progressPaint,
    );
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
