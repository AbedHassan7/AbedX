import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiz_app/models/quiz_model.dart';
import 'package:quiz_app/screens/quiz_page.dart';
import 'package:quiz_app/services/quiz_provider.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:quiz_app/widgets/animated_background.dart';
import 'package:quiz_app/widgets/primary_button.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/widgets/difficulty_selector.dart';
import 'package:quiz_app/widgets/category_selector.dart';
import 'package:quiz_app/widgets/daily_challenge.dart';
import 'package:quiz_app/utils/page_transition.dart';
import 'package:lottie/lottie.dart';

class StartPage extends StatefulWidget {
  const StartPage({Key? key}) : super(key: key);

  @override
  State<StartPage> createState() => _StartPageState();
}

class _StartPageState extends State<StartPage> {
  DifficultyLevel _selectedDifficulty = DifficultyLevel.medium;
  late List<QuizCategory> _categories;
  late QuizCategory _selectedCategory;
  bool _showCategories = false;
  bool _showHowToPlay = false;
  late DailyChallenge _dailyChallenge;

  @override
  void initState() {
    super.initState();
    _categories = CategoryData.getCategories();
    _selectedCategory = _categories.first;
    _dailyChallenge = DailyChallengeData.getTodayChallenge();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBackground(
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 20),
                Center(
                  child: SizedBox(
                    height: 120,
                    child: Lottie.network(
                      'https://assets10.lottiefiles.com/packages/lf20_rjgikbck.json',
                      repeat: true,
                      animate: true,
                    ),
                  ),
                )
                .animate()
                .scale(
                  duration: 800.ms,
                  curve: Curves.elasticOut,
                  begin: const Offset(0.2, 0.2),
                  end: const Offset(1, 1),
                ),
                const SizedBox(height: 20),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [
                      AppTheme.primaryColor,
                      AppTheme.accentColor,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ).createShader(bounds),
                  child: Text(
                    'Quiz Master',
                    style: AppTheme.headingStyle.copyWith(
                      color: Colors.white,
                      fontSize: 36,
                    ),
                    textAlign: TextAlign.center,
                  ),
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 300.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 300.ms, curve: Curves.easeOutQuad),
                const SizedBox(height: 8),
                Text(
                  'Test your knowledge with fun quizzes!',
                  style: AppTheme.subheadingStyle.copyWith(
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 500.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 500.ms, curve: Curves.easeOutQuad),
                const SizedBox(height: 40),
                
                // Difficulty Selector
                DifficultySelector(
                  selectedDifficulty: _selectedDifficulty,
                  onDifficultyChanged: (difficulty) {
                    setState(() {
                      _selectedDifficulty = difficulty;
                    });
                    
                    // Update the difficulty in the provider
                    Provider.of<QuizProvider>(context, listen: false)
                        .setDifficulty(difficulty);
                  },
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 700.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 700.ms, curve: Curves.easeOutQuad),
                
                const SizedBox(height: 24),
                
                // Category Selection Button
                GestureDetector(
                  onTap: () {
                    setState(() {
                      _showCategories = !_showCategories;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _selectedCategory.icon,
                          color: _selectedCategory.color,
                          size: 28,
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Selected Category',
                                style: TextStyle(
                                  color: Colors.grey.shade600,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _selectedCategory.name,
                                style: TextStyle(
                                  color: _selectedCategory.color,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          _showCategories ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                          color: Colors.grey.shade600,
                        ),
                      ],
                    ),
                  ),
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 900.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 900.ms, curve: Curves.easeOutQuad),
                
                // Expandable Category List
                if (_showCategories)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.only(top: 16),
                    child: CategorySelector(
                      categories: _categories,
                      onCategorySelected: (category) {
                        setState(() {
                          _selectedCategory = category;
                          _showCategories = false;
                        });
                        
                        // Update the category in the provider
                        Provider.of<QuizProvider>(context, listen: false)
                            .setCategory(category);
                      },
                    ),
                  )
                  .animate()
                  .fadeIn(duration: 300.ms)
                  .slideY(begin: 0.1, end: 0, duration: 300.ms, curve: Curves.easeOutQuad),
                
                const SizedBox(height: 24),
                
                // Daily Challenge
                DailyChallengeCard(
                  challenge: _dailyChallenge,
                  onAccept: () {
                    // Handle daily challenge acceptance
                  },
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 1100.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 1100.ms, curve: Curves.easeOutQuad),
                
                const SizedBox(height: 40),
                
                // Feature highlights
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildFeatureItem(
                      icon: Icons.timer,
                      text: '${_selectedDifficulty.timePerQuestion}s Timer',
                      color: _selectedDifficulty.color,
                      delay: 1300,
                    ),
                    _buildFeatureItem(
                      icon: Icons.lightbulb,
                      text: '5 Tips Available',
                      color: Colors.amber,
                      delay: 1400,
                    ),
                    _buildFeatureItem(
                      icon: Icons.format_list_numbered,
                      text: '16 Questions',
                      color: Colors.green,
                      delay: 1500,
                    ),
                  ],
                ),
                
                const SizedBox(height: 40),
                
                // Start Button
                PrimaryButton(
                  text: 'START QUIZ',
                  onPressed: () {
                    // Pass the selected difficulty and category to the quiz provider
                    final quizProvider = Provider.of<QuizProvider>(context, listen: false);
                    quizProvider.setDifficulty(_selectedDifficulty);
                    quizProvider.setCategory(_selectedCategory);
                    
                    Navigator.push(
                      context,
                      PageTransition(
                        page: const QuizPage(),
                        type: TransitionType.fade,
                      ),
                    );
                  },
                  icon: Icons.play_arrow,
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 1600.ms)
                .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: 1600.ms, curve: Curves.easeOutQuad)
                .shimmer(
                  duration: 1500.ms,
                  color: Colors.white.withOpacity(0.8),
                  size: 0.2,
                  delay: 2000.ms,
                ),
                
                const SizedBox(height: 24),
                
                // Bottom buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildBottomButton(
                      icon: Icons.help_outline,
                      text: 'How to Play',
                      onTap: () {
                        setState(() {
                          _showHowToPlay = true;
                        });
                      },
                    ),
                    _buildBottomButton(
                      icon: Icons.emoji_events_outlined,
                      text: 'Achievements',
                      onTap: () {
                        // Navigate to achievements page
                      },
                    ),
                  ],
                )
                .animate()
                .fadeIn(duration: 600.ms, delay: 1800.ms),
              ],
            ),
          ),
        ),
      ),
      
      // How to Play Dialog
      floatingActionButton: _showHowToPlay
          ? null
          : FloatingActionButton(
              onPressed: () {
                setState(() {
                  _showHowToPlay = true;
                });
              },
              backgroundColor: AppTheme.primaryColor,
              child: const Icon(Icons.help_outline),
            ),
            
      // How to Play Dialog
      bottomSheet: _showHowToPlay
          ? Container(
              height: MediaQuery.of(context).size.height * 0.7,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'How to Play',
                          style: AppTheme.subheadingStyle.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white),
                          onPressed: () {
                            setState(() {
                              _showHowToPlay = false;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHowToPlayItem(
                            step: '1',
                            title: 'Select Difficulty',
                            description: 'Choose between Easy (45s), Medium (30s), or Hard (20s) difficulty levels. This affects how much time you have for each question.',
                          ),
                          _buildHowToPlayItem(
                            step: '2',
                            title: 'Choose a Category',
                            description: 'Select from different quiz categories like General Knowledge, Science, History, or Geography.',
                          ),
                          _buildHowToPlayItem(
                            step: '3',
                            title: 'Answer Questions',
                            description: 'Tap once to select an answer, then tap again to confirm your selection. You must confirm before the timer runs out!',
                          ),
                          _buildHowToPlayItem(
                            step: '4',
                            title: 'Use Tips',
                            description: 'You have 5 tips available for the entire quiz. Use them wisely when you\'re stuck!',
                          ),
                          _buildHowToPlayItem(
                            step: '5',
                            title: 'Complete the Quiz',
                            description: 'Answer all 16 questions to complete the quiz and see your results.',
                          ),
                          _buildHowToPlayItem(
                            step: '6',
                            title: 'Earn Achievements',
                            description: 'Unlock special achievements by performing well in quizzes.',
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )
          : null,
    );
  }
  
  Widget _buildFeatureItem({
    required IconData icon,
    required String text,
    required Color color,
    required int delay,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(
              color: color.withOpacity(0.5),
              width: 2,
            ),
          ),
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          text,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    )
    .animate()
    .fadeIn(duration: 600.ms, delay: delay.ms)
    .slideY(begin: 0.2, end: 0, duration: 600.ms, delay: delay.ms, curve: Curves.easeOutQuad);
  }
  
  Widget _buildBottomButton({
    required IconData icon,
    required String text,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(
            icon,
            color: Colors.white70,
            size: 24,
          ),
          const SizedBox(height: 4),
          Text(
            text,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildHowToPlayItem({
    required String step,
    required String title,
    required String description,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: AppTheme.primaryColor,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                step,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: AppTheme.primaryColor,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    color: Colors.grey.shade700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
