import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/utils/app_theme.dart';

class AchievementBadge {
  final String id;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final bool isUnlocked;

  const AchievementBadge({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    this.isUnlocked = false,
  });
}

class AchievementsPage extends StatelessWidget {
  final List<AchievementBadge> achievements;

  const AchievementsPage({
    Key? key,
    required this.achievements,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        title: const Text('Achievements'),
        backgroundColor: AppTheme.primaryColor,
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Collect badges by completing challenges!',
                style: AppTheme.subheadingStyle.copyWith(
                  color: AppTheme.primaryColor,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16.0),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.8,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: achievements.length,
                itemBuilder: (context, index) {
                  final achievement = achievements[index];
                  return _buildAchievementCard(achievement, index);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAchievementCard(AchievementBadge achievement, int index) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              achievement.isUnlocked ? achievement.color : Colors.grey.shade300,
              achievement.isUnlocked ? achievement.color.withOpacity(0.7) : Colors.grey.shade200,
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.9),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: achievement.isUnlocked ? achievement.color.withOpacity(0.5) : Colors.grey.withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Icon(
                  achievement.icon,
                  color: achievement.isUnlocked ? achievement.color : Colors.grey,
                  size: 30,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                achievement.title,
                style: TextStyle(
                  color: achievement.isUnlocked ? Colors.white : Colors.grey.shade700,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                achievement.description,
                style: TextStyle(
                  color: achievement.isUnlocked ? Colors.white.withOpacity(0.9) : Colors.grey.shade600,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              if (achievement.isUnlocked)
                const Icon(
                  Icons.check_circle,
                  color: Colors.white,
                )
              else
                const Icon(
                  Icons.lock,
                  color: Colors.grey,
                ),
            ],
          ),
        ),
      ),
    )
    .animate()
    .fadeIn(delay: (100 * index).ms, duration: 500.ms)
    .scale(
      begin: const Offset(0.8, 0.8),
      end: const Offset(1, 1),
      delay: (100 * index).ms,
      duration: 500.ms,
      curve: Curves.easeOutQuad,
    );
  }
}

// Sample achievements
class AchievementData {
  static List<AchievementBadge> getAchievements({
    required int score,
    required int totalQuestions,
    required int tipsUsed,
    required bool completedWithoutTips,
    required bool completedWithPerfectScore,
    required bool completedUnderTime,
  }) {
    final percentage = (score / totalQuestions) * 100;
    
    return [
      AchievementBadge(
        id: 'first_quiz',
        title: 'First Steps',
        description: 'Complete your first quiz',
        icon: Icons.emoji_events,
        color: Colors.blue,
        isUnlocked: true, // Always unlocked after completing a quiz
      ),
      AchievementBadge(
        id: 'perfect_score',
        title: 'Perfect Score',
        description: 'Answer all questions correctly',
        icon: Icons.star,
        color: Colors.amber,
        isUnlocked: completedWithPerfectScore,
      ),
      AchievementBadge(
        id: 'no_tips',
        title: 'Self-Reliant',
        description: 'Complete a quiz without using any tips',
        icon: Icons.lightbulb,
        color: Colors.orange,
        isUnlocked: completedWithoutTips,
      ),
      AchievementBadge(
        id: 'speed_demon',
        title: 'Speed Demon',
        description: 'Complete a quiz in record time',
        icon: Icons.speed,
        color: Colors.red,
        isUnlocked: completedUnderTime,
      ),
      AchievementBadge(
        id: 'knowledge_master',
        title: 'Knowledge Master',
        description: 'Score at least 80% on a quiz',
        icon: Icons.school,
        color: Colors.purple,
        isUnlocked: percentage >= 80,
      ),
      AchievementBadge(
        id: 'persistent',
        title: 'Persistent',
        description: 'Try again after not getting a perfect score',
        icon: Icons.replay,
        color: Colors.green,
        isUnlocked: percentage < 100,
      ),
    ];
  }
}
