import 'package:flutter/material.dart';

class Question {
  final String text;
  final List<String> options;
  final int correctAnswerIndex;
  final String? explanation;
  final List<String> tips;
  final String category; // Added category field

  const Question({
    required this.text,
    required this.options,
    required this.correctAnswerIndex,
    this.explanation,
    this.tips = const [],
    this.category = 'general', // Default category
  });
  
  bool isCorrectAnswer(int selectedIndex) {
    return selectedIndex == correctAnswerIndex;
  }
}

class Quiz {
  final String title;
  final List<Question> questions;
  int timePerQuestionInSeconds;
  final int totalTips;
  final String category; // Added category field
  
  int _currentQuestionIndex = 0;
  int _score = 0;
  int _remainingTips;
  List<String> _usedTips = [];
  
  Quiz({
    required this.title,
    required this.questions,
    this.timePerQuestionInSeconds = 30,
    this.totalTips = 5,
    this.category = 'general', // Default category
  }) : _remainingTips = totalTips;
  
  // Method to update timer duration based on difficulty
  void updateTimerDuration(int seconds) {
    timePerQuestionInSeconds = seconds;
  }
  
  Question get currentQuestion => questions[_currentQuestionIndex];
  
  int get currentQuestionIndex => _currentQuestionIndex;
  
  int get totalQuestions => questions.length;
  
  int get score => _score;
  
  int get remainingTips => _remainingTips;
  
  double get progress => (_currentQuestionIndex + 1) / totalQuestions;
  
  bool get isLastQuestion => _currentQuestionIndex == questions.length - 1;
  
  bool get hasNextQuestion => _currentQuestionIndex < questions.length - 1;
  
  void answerQuestion(int selectedAnswerIndex) {
    if (currentQuestion.isCorrectAnswer(selectedAnswerIndex)) {
      _score++;
    }
  }
  
  void nextQuestion() {
    if (hasNextQuestion) {
      _currentQuestionIndex++;
      _usedTips = [];
    }
  }
  
  void resetQuiz() {
    _currentQuestionIndex = 0;
    _score = 0;
    _remainingTips = totalTips;
    _usedTips = [];
  }
  
  String? useTip() {
    if (_remainingTips <= 0) {
      return null;
    }
    
    final availableTips = currentQuestion.tips
        .where((tip) => !_usedTips.contains(tip))
        .toList();
    
    if (availableTips.isEmpty) {
      return null;
    }
    
    final tip = availableTips.first;
    _usedTips.add(tip);
    _remainingTips--;
    
    return tip;
  }
  
  double getScorePercentage() {
    return _score / questions.length * 100;
  }
}

// Sample quiz data
class QuizData {
  // General Knowledge Quiz
  static Quiz getGeneralKnowledgeQuiz() {
    return Quiz(
      title: 'General Knowledge',
      category: 'general',
      questions: [
        Question(
          text: 'What is the capital of France?',
          options: ['London', 'Berlin', 'Paris', 'Madrid'],
          correctAnswerIndex: 2,
          explanation: 'Paris is the capital and most populous city of France.',
          tips: [
            'This city is known as the "City of Light"',
            'It is located on the Seine River',
            'It is home to the Eiffel Tower'
          ],
          category: 'general',
        ),
        Question(
          text: 'Which planet is known as the Red Planet?',
          options: ['Venus', 'Mars', 'Jupiter', 'Saturn'],
          correctAnswerIndex: 1,
          explanation: 'Mars is called the Red Planet because of its reddish appearance.',
          tips: [
            'This planet is named after the Roman god of war',
            'It has two moons: Phobos and Deimos',
            'It has the largest volcano in the solar system'
          ],
          category: 'general',
        ),
        Question(
          text: 'Who painted the Mona Lisa?',
          options: ['Vincent van Gogh', 'Pablo Picasso', 'Leonardo da Vinci', 'Michelangelo'],
          correctAnswerIndex: 2,
          explanation: 'The Mona Lisa was painted by Leonardo da Vinci in the early 16th century.',
          tips: [
            'This artist was also a scientist and inventor',
            'He was a key figure in the Renaissance period',
            'He also painted "The Last Supper"'
          ],
          category: 'general',
        ),
        Question(
          text: 'What is the largest ocean on Earth?',
          options: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'],
          correctAnswerIndex: 3,
          explanation: 'The Pacific Ocean is the largest and deepest ocean on Earth.',
          tips: [
            'This ocean covers more than 30% of the Earth\'s surface',
            'It is located between Asia and Australia on the west and the Americas on the east',
            'Its name means "peaceful sea"'
          ],
          category: 'general',
        ),
        // More general knowledge questions...
        Question(
          text: 'Which element has the chemical symbol "O"?',
          options: ['Gold', 'Oxygen', 'Osmium', 'Oganesson'],
          correctAnswerIndex: 1,
          explanation: 'Oxygen has the chemical symbol "O" and atomic number 8.',
          tips: [
            'This element is essential for human respiration',
            'It makes up about 21% of Earth\'s atmosphere',
            'Its name comes from Greek words meaning "acid former"'
          ],
          category: 'general',
        ),
        Question(
          text: 'Who wrote "Romeo and Juliet"?',
          options: ['Charles Dickens', 'Jane Austen', 'William Shakespeare', 'Mark Twain'],
          correctAnswerIndex: 2,
          explanation: '"Romeo and Juliet" is a tragedy written by William Shakespeare.',
          tips: [
            'This playwright is often referred to as the "Bard of Avon"',
            'He wrote approximately 37 plays and 154 sonnets',
            'He lived during the Elizabethan era in England'
          ],
          category: 'general',
        ),
        Question(
          text: 'What is the tallest mountain in the world?',
          options: ['K2', 'Mount Everest', 'Kangchenjunga', 'Makalu'],
          correctAnswerIndex: 1,
          explanation: 'Mount Everest is the tallest mountain above sea level at 8,848.86 meters (29,031.7 feet).',
          tips: [
            'This mountain is located in the Mahalangur Himal sub-range of the Himalayas',
            'It sits on the border between Nepal and Tibet',
            'It was named after Sir George Everest, a British surveyor'
          ],
          category: 'general',
        ),
        Question(
          text: 'Which country is known as the Land of the Rising Sun?',
          options: ['China', 'South Korea', 'Thailand', 'Japan'],
          correctAnswerIndex: 3,
          explanation: 'Japan is known as the Land of the Rising Sun because from China, Japan appears to be in the direction where the sun rises.',
          tips: [
            'This island nation is located in East Asia',
            'Its flag features a red circle on a white background',
            'Its capital city is Tokyo'
          ],
          category: 'general',
        ),
        Question(
          text: 'What is the smallest prime number?',
          options: ['0', '1', '2', '3'],
          correctAnswerIndex: 2,
          explanation: '2 is the smallest prime number and the only even prime number.',
          tips: [
            'Prime numbers are only divisible by 1 and themselves',
            'This number is the only even prime number',
            'It is the first number in the Fibonacci sequence after 1'
          ],
          category: 'general',
        ),
        Question(
          text: 'Which of these is not a primary color in painting?',
          options: ['Red', 'Blue', 'Green', 'Yellow'],
          correctAnswerIndex: 2,
          explanation: 'In traditional color theory, the primary colors for painting are red, blue, and yellow. Green is a secondary color made by mixing blue and yellow.',
          tips: [
            'Primary colors cannot be created by mixing other colors',
            'This color is created by mixing two primary colors',
            'In RGB color model used for digital displays, this IS a primary color'
          ],
          category: 'general',
        ),
        // Additional general knowledge questions...
        Question(
          text: 'Which famous scientist developed the theory of relativity?',
          options: ['Isaac Newton', 'Albert Einstein', 'Galileo Galilei', 'Stephen Hawking'],
          correctAnswerIndex: 1,
          explanation: 'Albert Einstein developed the theory of relativity, which revolutionized our understanding of space, time, and gravity.',
          tips: [
            'This scientist was born in Germany in 1879',
            'He won the Nobel Prize in Physics in 1921',
            'His famous equation is E=mc²'
          ],
          category: 'general',
        ),
        Question(
          text: 'What is the chemical symbol for gold?',
          options: ['Go', 'Gd', 'Au', 'Ag'],
          correctAnswerIndex: 2,
          explanation: 'The chemical symbol for gold is "Au", which comes from the Latin word "aurum".',
          tips: [
            'This element\'s symbol comes from its Latin name',
            'It is a precious metal used in jewelry',
            'It has the atomic number 79 on the periodic table'
          ],
          category: 'general',
        ),
        Question(
          text: 'Which of these animals is not a mammal?',
          options: ['Dolphin', 'Bat', 'Penguin', 'Kangaroo'],
          correctAnswerIndex: 2,
          explanation: 'Penguins are birds, not mammals. They lay eggs and have feathers instead of fur or hair.',
          tips: [
            'Mammals typically give birth to live young',
            'Mammals typically have hair or fur',
            'This animal lays eggs and has feathers'
          ],
          category: 'general',
        ),
        Question(
          text: 'What is the largest organ in the human body?',
          options: ['Heart', 'Liver', 'Brain', 'Skin'],
          correctAnswerIndex: 3,
          explanation: 'The skin is the largest organ in the human body, both by weight and surface area.',
          tips: [
            'This organ covers the entire body',
            'It serves as a protective barrier',
            'It regulates body temperature'
          ],
          category: 'general',
        ),
        Question(
          text: 'Which of these countries is not in Europe?',
          options: ['Portugal', 'Turkey', 'Thailand', 'Sweden'],
          correctAnswerIndex: 2,
          explanation: 'Thailand is located in Southeast Asia, not Europe.',
          tips: [
            'This country is located in Southeast Asia',
            'Its capital is Bangkok',
            'It was formerly known as Siam'
          ],
          category: 'general',
        ),
        Question(
          text: 'Who is known as the "Father of Computer Science"?',
          options: ['Alan Turing', 'Bill Gates', 'Steve Jobs', 'Tim Berners-Lee'],
          correctAnswerIndex: 0,
          explanation: 'Alan Turing is widely considered to be the father of computer science and artificial intelligence.',
          tips: [
            'This person helped crack the Enigma code during World War II',
            'He developed the concept of the Turing machine',
            'The Turing Test for artificial intelligence is named after him'
          ],
          category: 'general',
        ),
      ],
      timePerQuestionInSeconds: 30,
      totalTips: 5,
    );
  }
  
  // Science Quiz
  static Quiz getScienceQuiz() {
    return Quiz(
      title: 'Science & Technology',
      category: 'science',
      questions: [
        Question(
          text: 'What is the chemical symbol for water?',
          options: ['WA', 'H2O', 'W', 'HO'],
          correctAnswerIndex: 1,
          explanation: 'Water is composed of two hydrogen atoms and one oxygen atom, hence H2O.',
          tips: [
            'This compound is essential for life',
            'It contains hydrogen and oxygen',
            'It covers about 71% of Earth\'s surface'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which scientist proposed the theory of evolution by natural selection?',
          options: ['Isaac Newton', 'Charles Darwin', 'Albert Einstein', 'Galileo Galilei'],
          correctAnswerIndex: 1,
          explanation: 'Charles Darwin proposed the theory of evolution by natural selection in his book "On the Origin of Species" published in 1859.',
          tips: [
            'This scientist traveled on the HMS Beagle',
            'He studied finches in the Galapagos Islands',
            'His theory explains how species adapt over time'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the smallest unit of matter?',
          options: ['Atom', 'Molecule', 'Cell', 'Quark'],
          correctAnswerIndex: 3,
          explanation: 'Quarks are elementary particles and the fundamental constituents of matter, making them smaller than atoms.',
          tips: [
            'This unit is smaller than an atom',
            'It is an elementary particle',
            'There are six types or "flavors" of these particles'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the speed of light in a vacuum?',
          options: ['300,000 km/s', '150,000 km/s', '500,000 km/s', '1,000,000 km/s'],
          correctAnswerIndex: 0,
          explanation: 'The speed of light in a vacuum is approximately 299,792,458 meters per second, or about 300,000 kilometers per second.',
          tips: [
            'This speed is represented by the symbol "c" in physics',
            'It is the fastest speed at which energy, matter, or information can travel',
            'According to Einstein\'s theory of relativity, nothing can travel faster than this'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which of these is not a type of renewable energy?',
          options: ['Solar', 'Wind', 'Nuclear', 'Hydroelectric'],
          correctAnswerIndex: 2,
          explanation: 'Nuclear energy is not considered renewable because it uses uranium, which is a finite resource.',
          tips: [
            'Renewable energy comes from sources that naturally replenish',
            'This energy source uses uranium or plutonium',
            'It produces energy through fission or fusion'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the main function of DNA?',
          options: ['Energy production', 'Genetic information storage', 'Protein synthesis', 'Cell division'],
          correctAnswerIndex: 1,
          explanation: 'DNA (deoxyribonucleic acid) stores genetic information that is used for the development and functioning of all living organisms.',
          tips: [
            'This molecule has a double helix structure',
            'It contains the instructions for building and maintaining an organism',
            'It is passed from parents to offspring'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which planet has the most moons?',
          options: ['Jupiter', 'Saturn', 'Uranus', 'Neptune'],
          correctAnswerIndex: 1,
          explanation: 'Saturn has the most moons with 82 confirmed moons, while Jupiter has 79.',
          tips: [
            'This planet is known for its prominent rings',
            'It is the sixth planet from the Sun',
            'It is a gas giant'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the hardest natural substance on Earth?',
          options: ['Steel', 'Diamond', 'Titanium', 'Graphene'],
          correctAnswerIndex: 1,
          explanation: 'Diamond is the hardest known natural material on Earth, scoring 10 on the Mohs scale of mineral hardness.',
          tips: [
            'This substance is made of carbon atoms',
            'It is formed under high pressure and temperature',
            'It is often used in jewelry'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which of these is not a state of matter?',
          options: ['Solid', 'Liquid', 'Gas', 'Energy'],
          correctAnswerIndex: 3,
          explanation: 'Energy is not a state of matter. The four fundamental states of matter are solid, liquid, gas, and plasma.',
          tips: [
            'States of matter are different forms that matter can take',
            'This option is a property of matter, not a form of it',
            'It can be transferred or converted but not contained like matter'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the process by which plants make their own food?',
          options: ['Respiration', 'Photosynthesis', 'Fermentation', 'Digestion'],
          correctAnswerIndex: 1,
          explanation: 'Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to create oxygen and energy in the form of sugar.',
          tips: [
            'This process uses sunlight',
            'It converts carbon dioxide and water into glucose and oxygen',
            'It takes place in the chloroplasts of plant cells'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which scientist discovered penicillin?',
          options: ['Alexander Fleming', 'Louis Pasteur', 'Marie Curie', 'Robert Koch'],
          correctAnswerIndex: 0,
          explanation: 'Alexander Fleming discovered penicillin in 1928 when he noticed that a mold (Penicillium notatum) had contaminated one of his bacterial cultures.',
          tips: [
            'This discovery was accidental',
            'It led to the development of antibiotics',
            'The scientist won the Nobel Prize in Physiology or Medicine in 1945'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the smallest bone in the human body?',
          options: ['Femur', 'Stapes', 'Radius', 'Phalanges'],
          correctAnswerIndex: 1,
          explanation: 'The stapes (stirrup) is the smallest bone in the human body, located in the middle ear.',
          tips: [
            'This bone is located in the ear',
            'It is one of three bones in the middle ear',
            'It is shaped like a stirrup'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which of these is not one of Newton\'s laws of motion?',
          options: ['An object in motion stays in motion', 'Force equals mass times acceleration', 'For every action there is an equal and opposite reaction', 'Energy cannot be created or destroyed'],
          correctAnswerIndex: 3,
          explanation: 'The law stating that energy cannot be created or destroyed is the law of conservation of energy, not one of Newton\'s laws of motion.',
          tips: [
            'Newton\'s laws of motion describe the relationship between an object and the forces acting upon it',
            'This law is related to thermodynamics',
            'This law is about energy conservation'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the main component of the Sun?',
          options: ['Oxygen', 'Carbon', 'Hydrogen', 'Helium'],
          correctAnswerIndex: 2,
          explanation: 'The Sun is composed primarily of hydrogen (about 73% of its mass), with helium making up most of the remainder.',
          tips: [
            'This element is the lightest and most abundant in the universe',
            'It has atomic number 1',
            'The Sun converts this element into helium through nuclear fusion'
          ],
          category: 'science',
        ),
        Question(
          text: 'Which of these animals is cold-blooded?',
          options: ['Dolphin', 'Penguin', 'Lizard', 'Elephant'],
          correctAnswerIndex: 2,
          explanation: 'Lizards are reptiles, which are cold-blooded (ectothermic), meaning they cannot regulate their body temperature internally.',
          tips: [
            'Cold-blooded animals rely on external heat sources',
            'This animal is a reptile',
            'It often basks in the sun to warm up'
          ],
          category: 'science',
        ),
        Question(
          text: 'What is the unit of electrical resistance?',
          options: ['Watt', 'Volt', 'Ampere', 'Ohm'],
          correctAnswerIndex: 3,
          explanation: 'The ohm (Ω) is the SI unit of electrical resistance.',
          tips: [
            'This unit is named after a German physicist',
            'It measures how much a material opposes the flow of electric current',
            'It is represented by the Greek letter omega (Ω)'
          ],
          category: 'science',
        ),
      ],
      timePerQuestionInSeconds: 30,
      totalTips: 5,
    );
  }
  
  // History Quiz
  static Quiz getHistoryQuiz() {
    return Quiz(
      title: 'History',
      category: 'history',
      questions: [
        Question(
          text: 'In which year did World War I begin?',
          options: ['1914', '1916', '1918', '1939'],
          correctAnswerIndex: 0,
          explanation: 'World War I began in 1914 following the assassination of Archduke Franz Ferdinand of Austria.',
          tips: [
            'This war was triggered by an assassination in Sarajevo',
            'It ended in 1918',
            'It was called "The Great War" before World War II'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who was the first President of the United States?',
          options: ['Thomas Jefferson', 'John Adams', 'George Washington', 'Benjamin Franklin'],
          correctAnswerIndex: 2,
          explanation: 'George Washington was the first President of the United States, serving from 1789 to 1797.',
          tips: [
            'This person led the Continental Army during the American Revolutionary War',
            'His face appears on the one-dollar bill',
            'He refused to serve more than two terms'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which ancient civilization built the pyramids at Giza?',
          options: ['Romans', 'Greeks', 'Mayans', 'Egyptians'],
          correctAnswerIndex: 3,
          explanation: 'The ancient Egyptians built the pyramids at Giza, with the Great Pyramid being constructed around 2560 BCE.',
          tips: [
            'This civilization was located along the Nile River',
            'They had pharaohs as rulers',
            'They developed hieroglyphics as a writing system'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who wrote "The Communist Manifesto"?',
          options: ['Vladimir Lenin', 'Karl Marx and Friedrich Engels', 'Joseph Stalin', 'Leon Trotsky'],
          correctAnswerIndex: 1,
          explanation: '"The Communist Manifesto" was written by Karl Marx and Friedrich Engels and published in 1848.',
          tips: [
            'This document was published in 1848',
            'It begins with "A spectre is haunting Europe"',
            'It was commissioned by the Communist League'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which empire was ruled by Genghis Khan?',
          options: ['Roman Empire', 'Ottoman Empire', 'Mongol Empire', 'Byzantine Empire'],
          correctAnswerIndex: 2,
          explanation: 'Genghis Khan founded and ruled the Mongol Empire, which became the largest contiguous land empire in history.',
          tips: [
            'This empire originated in East Asia',
            'It was the largest contiguous land empire in history',
            'Its founder united many nomadic tribes'
          ],
          category: 'history',
        ),
        Question(
          text: 'When did the French Revolution begin?',
          options: ['1789', '1776', '1804', '1815'],
          correctAnswerIndex: 0,
          explanation: 'The French Revolution began in 1789 with the storming of the Bastille on July 14.',
          tips: [
            'This event began with the storming of the Bastille',
            'It led to the end of the monarchy in France',
            'It was influenced by Enlightenment ideals'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who discovered America in 1492?',
          options: ['Vasco da Gama', 'Ferdinand Magellan', 'Christopher Columbus', 'Amerigo Vespucci'],
          correctAnswerIndex: 2,
          explanation: 'Christopher Columbus reached the Americas in 1492, although he believed he had reached the East Indies.',
          tips: [
            'This explorer sailed under the Spanish flag',
            'He had three ships: the Niña, the Pinta, and the Santa Maria',
            'He was searching for a western route to Asia'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which country was the first to send a human to space?',
          options: ['United States', 'Soviet Union', 'China', 'United Kingdom'],
          correctAnswerIndex: 1,
          explanation: 'The Soviet Union was the first country to send a human to space when Yuri Gagarin orbited Earth on April 12, 1961.',
          tips: [
            'This country no longer exists',
            'The first human in space was Yuri Gagarin',
            'This achievement occurred during the Cold War'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who was the leader of the Soviet Union during most of World War II?',
          options: ['Vladimir Lenin', 'Leon Trotsky', 'Joseph Stalin', 'Nikita Khrushchev'],
          correctAnswerIndex: 2,
          explanation: 'Joseph Stalin was the leader of the Soviet Union during most of World War II, from the beginning of the war until its end.',
          tips: [
            'This leader ruled from 1922 to 1953',
            'He implemented five-year plans for rapid industrialization',
            'He was part of the "Big Three" with Churchill and Roosevelt'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which treaty ended World War I?',
          options: ['Treaty of Versailles', 'Treaty of Paris', 'Treaty of Westphalia', 'Treaty of Tordesillas'],
          correctAnswerIndex: 0,
          explanation: 'The Treaty of Versailles, signed on June 28, 1919, formally ended World War I.',
          tips: [
            'This treaty was signed in 1919',
            'It was signed at the Palace of Versailles in France',
            'It imposed harsh penalties on Germany'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who was the first woman to win a Nobel Prize?',
          options: ['Marie Curie', 'Rosalind Franklin', 'Dorothy Hodgkin', 'Irène Joliot-Curie'],
          correctAnswerIndex: 0,
          explanation: 'Marie Curie was the first woman to win a Nobel Prize, winning the Physics Prize in 1903 and the Chemistry Prize in 1911.',
          tips: [
            'This scientist discovered the elements polonium and radium',
            'She won Nobel Prizes in two different scientific fields',
            'She was born in Poland but worked in France'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which civilization developed the first known writing system?',
          options: ['Egyptians', 'Sumerians', 'Chinese', 'Mayans'],
          correctAnswerIndex: 1,
          explanation: 'The Sumerians developed the first known writing system, cuneiform, around 3400-3200 BCE.',
          tips: [
            'This civilization lived in Mesopotamia (modern-day Iraq)',
            'Their writing system used wedge-shaped marks on clay tablets',
            'They built ziggurats as religious temples'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who was the first Emperor of China?',
          options: ['Kublai Khan', 'Qin Shi Huang', 'Emperor Wu of Han', 'Emperor Taizong of Tang'],
          correctAnswerIndex: 1,
          explanation: 'Qin Shi Huang (259-210 BCE) was the first Emperor of China, unifying China in 221 BCE.',
          tips: [
            'This ruler unified China in 221 BCE',
            'He ordered the construction of the Great Wall',
            'His tomb contains the famous Terracotta Army'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which event marked the beginning of World War II in Europe?',
          options: ['German invasion of Poland', 'Attack on Pearl Harbor', 'Fall of France', 'Battle of Britain'],
          correctAnswerIndex: 0,
          explanation: 'World War II in Europe began with Nazi Germany\'s invasion of Poland on September 1, 1939.',
          tips: [
            'This event occurred on September 1, 1939',
            'It led Britain and France to declare war on Germany',
            'It involved a blitzkrieg (lightning war) strategy'
          ],
          category: 'history',
        ),
        Question(
          text: 'Who was the leader of the Indian independence movement against British rule?',
          options: ['Jawaharlal Nehru', 'Mahatma Gandhi', 'Subhas Chandra Bose', 'Sardar Patel'],
          correctAnswerIndex: 1,
          explanation: 'Mahatma Gandhi led the Indian independence movement against British rule through nonviolent civil disobedience.',
          tips: [
            'This leader advocated for nonviolent civil disobedience',
            'He was known as "Mahatma" (Great Soul)',
            'He led the Salt March in 1930'
          ],
          category: 'history',
        ),
        Question(
          text: 'Which ancient wonder was located in Alexandria, Egypt?',
          options: ['Hanging Gardens', 'Colossus of Rhodes', 'Lighthouse (Pharos)', 'Temple of Artemis'],
          correctAnswerIndex: 2,
          explanation: 'The Lighthouse of Alexandria (Pharos) was one of the Seven Wonders of the Ancient World, located in Alexandria, Egypt.',
          tips: [
            'This structure was built in the 3rd century BCE',
            'It was one of the tallest structures of the ancient world',
            'It guided ships into the harbor'
          ],
          category: 'history',
        ),
      ],
      timePerQuestionInSeconds: 30,
      totalTips: 5,
    );
  }
  
  // Geography Quiz
  static Quiz getGeographyQuiz() {
    return Quiz(
      title: 'Geography',
      category: 'geography',
      questions: [
        Question(
          text: 'Which is the largest continent by land area?',
          options: ['North America', 'Africa', 'Europe', 'Asia'],
          correctAnswerIndex: 3,
          explanation: 'Asia is the largest continent by land area, covering approximately 44.58 million square kilometers.',
          tips: [
            'This continent contains about 60% of the world\'s population',
            'It includes countries like China, India, and Russia',
            'It is home to the highest mountain in the world'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country has the largest population in the world?',
          options: ['India', 'United States', 'China', 'Indonesia'],
          correctAnswerIndex: 2,
          explanation: 'China has the largest population in the world with over 1.4 billion people.',
          tips: [
            'This country is located in East Asia',
            'Its capital is Beijing',
            'It has the world\'s second-largest economy'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which river is the longest in the world?',
          options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'],
          correctAnswerIndex: 1,
          explanation: 'The Nile River is generally considered the longest river in the world, flowing for about 6,650 kilometers.',
          tips: [
            'This river flows through 11 countries',
            'It empties into the Mediterranean Sea',
            'Ancient Egyptian civilization developed along its banks'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which mountain is the highest in the world?',
          options: ['K2', 'Mount Everest', 'Kangchenjunga', 'Makalu'],
          correctAnswerIndex: 1,
          explanation: 'Mount Everest is the highest mountain above sea level at 8,848.86 meters (29,031.7 feet).',
          tips: [
            'This mountain is located in the Mahalangur Himal sub-range of the Himalayas',
            'It sits on the border between Nepal and Tibet',
            'It was named after Sir George Everest, a British surveyor'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which desert is the largest in the world?',
          options: ['Gobi Desert', 'Sahara Desert', 'Arabian Desert', 'Antarctic Desert'],
          correctAnswerIndex: 3,
          explanation: 'The Antarctic Desert is the largest desert in the world, covering about 14 million square kilometers.',
          tips: [
            'Deserts are defined by their low precipitation, not just by heat',
            'This desert is located at the South Pole',
            'It is covered in ice and snow'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country has the most natural lakes?',
          options: ['United States', 'Russia', 'Canada', 'Finland'],
          correctAnswerIndex: 2,
          explanation: 'Canada has the most natural lakes of any country, with over 2 million lakes.',
          tips: [
            'This country is the second-largest by land area',
            'It is located in North America',
            'Its lakes contain about 20% of the world\'s fresh water'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which ocean is the largest by surface area?',
          options: ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'],
          correctAnswerIndex: 3,
          explanation: 'The Pacific Ocean is the largest and deepest ocean on Earth, covering more than 30% of the Earth\'s surface.',
          tips: [
            'This ocean covers more than 30% of the Earth\'s surface',
            'It is located between Asia and Australia on the west and the Americas on the east',
            'Its name means "peaceful sea"'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country has the most time zones?',
          options: ['Russia', 'United States', 'France', 'Australia'],
          correctAnswerIndex: 2,
          explanation: 'France has the most time zones with 12, due to its overseas territories spread around the world.',
          tips: [
            'This country has territories on multiple continents',
            'It is located in Western Europe',
            'Its overseas territories include islands in the Pacific, Caribbean, and Indian Ocean'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which is the smallest country in the world by land area?',
          options: ['Monaco', 'Nauru', 'Vatican City', 'San Marino'],
          correctAnswerIndex: 2,
          explanation: 'Vatican City is the smallest country in the world by land area, covering just 0.49 square kilometers.',
          tips: [
            'This country is an enclave within Rome, Italy',
            'It is the spiritual center of the Roman Catholic Church',
            'Its head of state is the Pope'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country is both in Europe and Asia?',
          options: ['Russia', 'Turkey', 'Kazakhstan', 'All of these'],
          correctAnswerIndex: 3,
          explanation: 'Russia, Turkey, and Kazakhstan all have territory in both Europe and Asia, making them transcontinental countries.',
          tips: [
            'These countries span the conventional boundary between Europe and Asia',
            'The Ural Mountains and the Bosporus Strait are often considered dividing lines',
            'All three countries have most of their land in Asia'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which is the driest continent on Earth?',
          options: ['Africa', 'Australia', 'Antarctica', 'South America'],
          correctAnswerIndex: 1,
          explanation: 'Australia is the driest inhabited continent on Earth, with an average annual rainfall of less than 500 mm over 70% of its land area.',
          tips: [
            'This continent is also the smallest continent',
            'It is surrounded entirely by water',
            'Much of its interior is desert'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country has the longest coastline in the world?',
          options: ['Russia', 'Indonesia', 'Canada', 'Australia'],
          correctAnswerIndex: 2,
          explanation: 'Canada has the longest coastline in the world, stretching for about 202,080 kilometers.',
          tips: [
            'This country borders three oceans',
            'It has numerous islands and inlets',
            'It is the second-largest country by land area'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which of these cities is not a national capital?',
          options: ['Ottawa', 'Canberra', 'Sydney', 'Wellington'],
          correctAnswerIndex: 2,
          explanation: 'Sydney is not a national capital. The capital of Australia is Canberra.',
          tips: [
            'This city is the largest city in its country',
            'It is known for its iconic opera house',
            'Many people mistakenly believe it is the capital of its country'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which African country was never colonized by Europeans?',
          options: ['South Africa', 'Ethiopia', 'Kenya', 'Nigeria'],
          correctAnswerIndex: 1,
          explanation: 'Ethiopia was never successfully colonized by Europeans, although Italy briefly occupied it from 1936 to 1941.',
          tips: [
            'This country successfully resisted Italian invasion at the Battle of Adwa in 1896',
            'It is located in the Horn of Africa',
            'It has one of the oldest Christian traditions in the world'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which strait separates Asia from North America?',
          options: ['Strait of Gibraltar', 'Bering Strait', 'Strait of Malacca', 'Strait of Hormuz'],
          correctAnswerIndex: 1,
          explanation: 'The Bering Strait separates Asia (Russia) from North America (Alaska, USA), with a width of about 82 kilometers.',
          tips: [
            'This strait is named after a Danish explorer',
            'It connects the Arctic Ocean with the Bering Sea',
            'It freezes over in winter, potentially allowing crossing on foot'
          ],
          category: 'geography',
        ),
        Question(
          text: 'Which country is home to the Great Barrier Reef?',
          options: ['Indonesia', 'Philippines', 'Australia', 'Thailand'],
          correctAnswerIndex: 2,
          explanation: 'The Great Barrier Reef is located off the coast of Queensland, Australia, and is the world\'s largest coral reef system.',
          tips: [
            'This reef system stretches for over 2,300 kilometers',
            'It can be seen from space',
            'It is a UNESCO World Heritage site'
          ],
          category: 'geography',
        ),
      ],
      timePerQuestionInSeconds: 30,
      totalTips: 5,
    );
  }
}
