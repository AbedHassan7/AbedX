import 'package:flutter/material.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:flutter_animate/flutter_animate.dart';

class AnswerOption extends StatelessWidget {
  final String text;
  final bool isSelected;
  final bool isConfirmed;
  final bool isCorrect;
  final bool showResult;
  final Function(bool confirmed) onTap;
  final int index;

  const AnswerOption({
    Key? key,
    required this.text,
    required this.isSelected,
    this.isConfirmed = false,
    required this.isCorrect,
    required this.onTap,
    required this.index,
    this.showResult = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color backgroundColor;
    Color borderColor;
    Color textColor;

    if (showResult) {
      if (isCorrect) {
        backgroundColor = AppTheme.correctAnswerColor.withOpacity(0.2);
        borderColor = AppTheme.correctAnswerColor;
        textColor = AppTheme.textPrimaryColor;
      } else if (isSelected && !isCorrect) {
        backgroundColor = AppTheme.wrongAnswerColor.withOpacity(0.2);
        borderColor = AppTheme.wrongAnswerColor;
        textColor = AppTheme.textPrimaryColor;
      } else {
        backgroundColor = AppTheme.accentColor;
        borderColor = AppTheme.neutralColor.withOpacity(0.3);
        textColor = AppTheme.textPrimaryColor;
      }
    } else {
      if (isConfirmed) {
        backgroundColor = AppTheme.primaryColor.withOpacity(0.4);
        borderColor = AppTheme.primaryColor;
        textColor = AppTheme.primaryColor;
      } else if (isSelected) {
        backgroundColor = AppTheme.primaryColor.withOpacity(0.2);
        borderColor = AppTheme.primaryColor;
        textColor = AppTheme.primaryColor;
      } else {
        backgroundColor = AppTheme.accentColor;
        borderColor = AppTheme.neutralColor.withOpacity(0.3);
        textColor = AppTheme.textPrimaryColor;
      }
    }

    return GestureDetector(
      onTap: showResult ? null : () => onTap(isSelected),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor, width: 2),
          boxShadow: (isSelected || isConfirmed) ? AppTheme.primaryShadow : null,
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: isSelected ? AppTheme.primaryColor : AppTheme.accentColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSelected ? AppTheme.primaryColor : AppTheme.neutralColor.withOpacity(0.5),
                  width: 2,
                ),
              ),
              child: Center(
                child: Text(
                  String.fromCharCode(65 + index), // A, B, C, D
                  style: TextStyle(
                    color: isSelected ? AppTheme.textLightColor : AppTheme.textPrimaryColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                text,
                style: AppTheme.bodyStyle.copyWith(
                  color: textColor,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
            if (showResult && isCorrect)
              const Icon(Icons.check_circle, color: AppTheme.correctAnswerColor),
            if (showResult && isSelected && !isCorrect)
              const Icon(Icons.cancel, color: AppTheme.wrongAnswerColor),
            if (isSelected && !isConfirmed && !showResult)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Tap to confirm',
                  style: TextStyle(
                    color: AppTheme.accentColor,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              )
              .animate(onPlay: (controller) => controller.repeat(reverse: true))
              .fadeIn(duration: 300.ms)
              .then()
              .scale(
                begin: const Offset(0.95, 0.95),
                end: const Offset(1.05, 1.05),
                duration: 500.ms,
              ),
          ],
        ),
      ),
    )
    .animate()
    .fadeIn(duration: 300.ms, delay: (100 * index).ms)
    .slideX(begin: 0.2, end: 0, duration: 300.ms, delay: (100 * index).ms, curve: Curves.easeOutQuad);
  }
}
