import 'package:flutter/material.dart';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/utils/app_theme.dart';

class QuizTimer extends StatelessWidget {
  final int duration;
  final Function onComplete;
  final CountDownController controller;
  final bool isRunning;
  final Color? difficultyColor; // Added parameter for difficulty color

  const QuizTimer({
    Key? key,
    required this.duration,
    required this.onComplete,
    required this.controller,
    required this.isRunning,
    this.difficultyColor, // Optional parameter with default value
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: (difficultyColor ?? AppTheme.primaryColor).withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: CircularCountDownTimer(
        duration: duration,
        initialDuration: 0,
        controller: controller,
        width: 70,
        height: 70,
        ringColor: Colors.grey.shade200,
        fillColor: difficultyColor ?? AppTheme.primaryColor,
        backgroundColor: Colors.white,
        strokeWidth: 8.0,
        strokeCap: StrokeCap.round,
        textStyle: TextStyle(
          fontSize: 18.0,
          color: difficultyColor ?? AppTheme.primaryColor,
          fontWeight: FontWeight.bold,
        ),
        textFormat: CountdownTextFormat.S,
        isReverse: true,
        isReverseAnimation: true,
        isTimerTextShown: true,
        autoStart: isRunning,
        onComplete: () => onComplete(),
      ),
    )
    .animate(target: isRunning ? 1 : 0)
    .shimmer(
      duration: 1500.ms,
      color: (difficultyColor ?? AppTheme.primaryColor).withOpacity(0.7),
      size: 0.2,
      delay: 1000.ms,
    );
  }
}
