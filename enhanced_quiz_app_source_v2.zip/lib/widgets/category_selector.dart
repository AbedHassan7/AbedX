import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/utils/app_theme.dart';

class QuizCategory {
  final String id;
  final String name;
  final String description;
  final IconData icon;
  final Color color;
  final bool isLocked;

  const QuizCategory({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.color,
    this.isLocked = false,
  });
}

class CategorySelector extends StatelessWidget {
  final List<QuizCategory> categories;
  final Function(QuizCategory) onCategorySelected;

  const CategorySelector({
    Key? key,
    required this.categories,
    required this.onCategorySelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quiz Categories',
            style: AppTheme.subheadingStyle.copyWith(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: categories.length,
            itemBuilder: (context, index) {
              final category = categories[index];
              return _buildCategoryCard(category, index);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(QuizCategory category, int index) {
    return GestureDetector(
      onTap: category.isLocked ? null : () => onCategorySelected(category),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              category.isLocked ? Colors.grey.shade300 : category.color.withOpacity(0.7),
              category.isLocked ? Colors.grey.shade200 : category.color.withOpacity(0.9),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: category.isLocked ? Colors.grey.withOpacity(0.3) : category.color.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                shape: BoxShape.circle,
              ),
              child: Icon(
                category.icon,
                color: category.isLocked ? Colors.grey : category.color,
                size: 28,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    category.name,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    category.description,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (category.isLocked)
              const Icon(
                Icons.lock,
                color: Colors.white,
              ),
          ],
        ),
      ),
    )
    .animate()
    .fadeIn(delay: (100 * index).ms, duration: 500.ms)
    .slideX(
      begin: 0.1,
      end: 0,
      delay: (100 * index).ms,
      duration: 500.ms,
      curve: Curves.easeOutQuad,
    );
  }
}

// Sample categories
class CategoryData {
  static List<QuizCategory> getCategories() {
    return [
      const QuizCategory(
        id: 'general',
        name: 'General Knowledge',
        description: 'Test your knowledge on various topics',
        icon: Icons.lightbulb,
        color: Colors.blue,
      ),
      const QuizCategory(
        id: 'science',
        name: 'Science & Technology',
        description: 'Questions about science, technology, and innovation',
        icon: Icons.science,
        color: Colors.green,
      ),
      const QuizCategory(
        id: 'history',
        name: 'History',
        description: 'Explore the past with historical questions',
        icon: Icons.history,
        color: Colors.amber,
      ),
      const QuizCategory(
        id: 'geography',
        name: 'Geography',
        description: 'Test your knowledge of places around the world',
        icon: Icons.public,
        color: Colors.purple,
      ),
      const QuizCategory(
        id: 'entertainment',
        name: 'Entertainment',
        description: 'Questions about movies, music, and pop culture',
        icon: Icons.movie,
        color: Colors.red,
        isLocked: true,
      ),
    ];
  }
}
