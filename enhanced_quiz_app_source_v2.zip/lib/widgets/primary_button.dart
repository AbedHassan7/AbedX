import 'package:flutter/material.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:flutter_animate/flutter_animate.dart';

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;
  final bool isFullWidth;
  final bool isOutlined;
  final IconData? icon;

  const PrimaryButton({
    Key? key,
    required this.text,
    required this.onPressed,
    this.isFullWidth = true,
    this.isOutlined = false,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final buttonStyle = isOutlined
        ? ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            foregroundColor: AppTheme.primaryColor,
            elevation: 0,
            side: const BorderSide(color: AppTheme.primaryColor, width: 2),
          )
        : null;

    final buttonContent = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[
          Icon(icon),
          const SizedBox(width: 8),
        ],
        Text(text),
      ],
    );

    return SizedBox(
      width: isFullWidth ? double.infinity : null,
      child: ElevatedButton(
        onPressed: onPressed,
        style: buttonStyle,
        child: buttonContent,
      ),
    )
    .animate()
    .scale(duration: 100.ms, curve: Curves.easeInOut)
    .then(delay: 50.ms)
    .shimmer(duration: 300.ms, color: AppTheme.accentColor.withOpacity(0.3));
  }
}
