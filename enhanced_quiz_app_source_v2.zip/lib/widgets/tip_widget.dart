import 'package:flutter/material.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:flutter_animate/flutter_animate.dart';

class TipWidget extends StatelessWidget {
  final int totalTips;
  final int remainingTips;
  final VoidCallback onUseTip;
  final String? currentTip;

  const TipWidget({
    Key? key,
    required this.totalTips,
    required this.remainingTips,
    required this.onUseTip,
    this.currentTip,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Tips: ',
              style: AppTheme.bodyStyle.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            Row(
              children: List.generate(
                totalTips,
                (index) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    Icons.lightbulb,
                    color: index < remainingTips
                        ? AppTheme.tipColor
                        : AppTheme.neutralColor.withOpacity(0.3),
                    size: 24,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (currentTip != null)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.tipColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.tipColor.withOpacity(0.5),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.lightbulb,
                  color: AppTheme.tipColor,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    currentTip!,
                    style: AppTheme.bodyStyle,
                  ),
                ),
              ],
            ),
          )
            .animate()
            .fadeIn(duration: 300.ms)
            .slideY(begin: 0.2, end: 0, duration: 300.ms, curve: Curves.easeOutQuad),
        if (currentTip == null && remainingTips > 0)
          ElevatedButton.icon(
            onPressed: onUseTip,
            icon: const Icon(Icons.lightbulb),
            label: const Text('Use a Tip'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.tipColor,
              foregroundColor: AppTheme.textLightColor,
            ),
          )
            .animate(onPlay: (controller) => controller.repeat(reverse: true))
            .scale(
              begin: const Offset(1, 1),
              end: const Offset(1.05, 1.05),
              duration: 1000.ms,
            ),
        if (remainingTips == 0 && currentTip == null)
          Text(
            'No tips remaining!',
            style: AppTheme.bodyStyle.copyWith(
              color: AppTheme.neutralColor,
              fontStyle: FontStyle.italic,
            ),
          ),
      ],
    );
  }
}
