import 'package:flutter/material.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:flutter_animate/flutter_animate.dart';

class AnimatedBackground extends StatelessWidget {
  final Widget child;
  final bool isActive;

  const AnimatedBackground({
    Key? key,
    required this.child,
    this.isActive = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: AppTheme.primaryGradient,
        ),
      ),
      child: Stack(
        children: [
          // Animated background elements
          if (isActive) ...[
            // Floating circles
            _buildAnimatedCircle(
              top: 50,
              left: 20,
              size: 100,
              delay: 0,
              duration: 7000,
            ),
            _buildAnimatedCircle(
              top: 150,
              right: 30,
              size: 80,
              delay: 1000,
              duration: 8000,
            ),
            _buildAnimatedCircle(
              bottom: 100,
              left: 40,
              size: 120,
              delay: 2000,
              duration: 9000,
            ),
            _buildAnimatedCircle(
              bottom: 200,
              right: 50,
              size: 90,
              delay: 3000,
              duration: 10000,
            ),
          ],
          
          // Main content
          child,
        ],
      ),
    );
  }
  
  Widget _buildAnimatedCircle({
    double? top,
    double? left,
    double? right,
    double? bottom,
    required double size,
    required int delay,
    required int duration,
  }) {
    return Positioned(
      top: top,
      left: left,
      right: right,
      bottom: bottom,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: AppTheme.accentColor.withOpacity(0.1),
        ),
      )
      .animate(
        onPlay: (controller) => controller.repeat(),
      )
      .moveY(
        begin: -10,
        end: 10,
        duration: duration.ms,
        delay: delay.ms,
        curve: Curves.easeInOut,
      )
      .moveX(
        begin: -5,
        end: 5,
        duration: (duration * 0.7).ms,
        delay: delay.ms,
        curve: Curves.easeInOut,
      )
      .scale(
        begin: const Offset(0.9, 0.9),
        end: const Offset(1.1, 1.1),
        duration: (duration * 0.8).ms,
        delay: delay.ms,
        curve: Curves.easeInOut,
      ),
    );
  }
}
