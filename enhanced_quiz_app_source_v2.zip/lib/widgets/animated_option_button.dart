import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/utils/app_theme.dart';

class AnimatedOptionButton extends StatelessWidget {
  final String text;
  final String optionLetter;
  final bool isSelected;
  final bool isCorrect;
  final bool showResult;
  final VoidCallback onTap;
  final int index;

  const AnimatedOptionButton({
    Key? key,
    required this.text,
    required this.optionLetter,
    required this.isSelected,
    required this.isCorrect,
    required this.onTap,
    required this.index,
    this.showResult = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color backgroundColor;
    Color borderColor;
    Color textColor;

    if (showResult) {
      if (isCorrect) {
        backgroundColor = AppTheme.correctAnswerColor.withOpacity(0.2);
        borderColor = AppTheme.correctAnswerColor;
        textColor = AppTheme.textPrimaryColor;
      } else if (isSelected && !isCorrect) {
        backgroundColor = AppTheme.wrongAnswerColor.withOpacity(0.2);
        borderColor = AppTheme.wrongAnswerColor;
        textColor = AppTheme.textPrimaryColor;
      } else {
        backgroundColor = AppTheme.accentColor;
        borderColor = AppTheme.neutralColor.withOpacity(0.3);
        textColor = AppTheme.textPrimaryColor;
      }
    } else {
      if (isSelected) {
        backgroundColor = AppTheme.primaryColor.withOpacity(0.2);
        borderColor = AppTheme.primaryColor;
        textColor = AppTheme.primaryColor;
      } else {
        backgroundColor = AppTheme.accentColor;
        borderColor = AppTheme.neutralColor.withOpacity(0.3);
        textColor = AppTheme.textPrimaryColor;
      }
    }

    return GestureDetector(
      onTap: showResult ? null : onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor, width: 2),
          boxShadow: isSelected ? AppTheme.primaryShadow : null,
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: isSelected ? AppTheme.primaryColor : AppTheme.accentColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: isSelected ? AppTheme.primaryColor : AppTheme.neutralColor.withOpacity(0.5),
                  width: 2,
                ),
                boxShadow: isSelected ? [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ] : null,
              ),
              child: Center(
                child: Text(
                  optionLetter,
                  style: TextStyle(
                    color: isSelected ? AppTheme.textLightColor : AppTheme.textPrimaryColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                text,
                style: AppTheme.bodyStyle.copyWith(
                  color: textColor,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
            if (showResult && isCorrect)
              const Icon(Icons.check_circle, color: AppTheme.correctAnswerColor)
                .animate(onPlay: (controller) => controller.repeat(reverse: true))
                .scale(
                  begin: const Offset(1, 1),
                  end: const Offset(1.2, 1.2),
                  duration: 700.ms,
                ),
            if (showResult && isSelected && !isCorrect)
              const Icon(Icons.cancel, color: AppTheme.wrongAnswerColor)
                .animate()
                .shake(duration: 500.ms, hz: 4),
          ],
        ),
      ),
    )
    .animate()
    .fadeIn(duration: 300.ms, delay: (100 * index).ms)
    .slideX(begin: 0.2, end: 0, duration: 300.ms, delay: (100 * index).ms, curve: Curves.easeOutQuad)
    .then(delay: 200.ms)
    .shimmer(
      duration: 1000.ms,
      color: isSelected ? AppTheme.primaryColor.withOpacity(0.3) : Colors.transparent,
    );
  }
}
