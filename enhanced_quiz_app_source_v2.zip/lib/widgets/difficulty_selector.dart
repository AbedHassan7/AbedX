import 'package:flutter/material.dart';
import 'package:quiz_app/utils/app_theme.dart';
import 'package:flutter_animate/flutter_animate.dart';

enum DifficultyLevel {
  easy,
  medium,
  hard
}

extension DifficultyLevelExtension on DifficultyLevel {
  String get name {
    switch (this) {
      case DifficultyLevel.easy:
        return 'Easy';
      case DifficultyLevel.medium:
        return 'Medium';
      case DifficultyLevel.hard:
        return 'Hard';
    }
  }
  
  Color get color {
    switch (this) {
      case DifficultyLevel.easy:
        return Colors.green;
      case DifficultyLevel.medium:
        return Colors.orange;
      case DifficultyLevel.hard:
        return Colors.red;
    }
  }
  
  IconData get icon {
    switch (this) {
      case DifficultyLevel.easy:
        return Icons.sentiment_satisfied;
      case DifficultyLevel.medium:
        return Icons.sentiment_neutral;
      case DifficultyLevel.hard:
        return Icons.sentiment_very_dissatisfied;
    }
  }
  
  int get timePerQuestion {
    switch (this) {
      case DifficultyLevel.easy:
        return 45;
      case DifficultyLevel.medium:
        return 30;
      case DifficultyLevel.hard:
        return 20;
    }
  }
}

class DifficultySelector extends StatelessWidget {
  final DifficultyLevel selectedDifficulty;
  final Function(DifficultyLevel) onDifficultyChanged;
  
  const DifficultySelector({
    Key? key,
    required this.selectedDifficulty,
    required this.onDifficultyChanged,
  }) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Difficulty',
            style: AppTheme.subheadingStyle.copyWith(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildDifficultyOption(DifficultyLevel.easy),
              const SizedBox(width: 12),
              _buildDifficultyOption(DifficultyLevel.medium),
              const SizedBox(width: 12),
              _buildDifficultyOption(DifficultyLevel.hard),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildDifficultyOption(DifficultyLevel difficulty) {
    final isSelected = selectedDifficulty == difficulty;
    
    return Expanded(
      child: GestureDetector(
        onTap: () => onDifficultyChanged(difficulty),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? difficulty.color.withOpacity(0.2) : Colors.grey.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? difficulty.color : Colors.transparent,
              width: 2,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                difficulty.icon,
                color: isSelected ? difficulty.color : Colors.grey,
                size: 28,
              ),
              const SizedBox(height: 8),
              Text(
                difficulty.name,
                style: TextStyle(
                  color: isSelected ? difficulty.color : Colors.grey.shade700,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${difficulty.timePerQuestion}s',
                style: TextStyle(
                  color: isSelected ? difficulty.color : Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      )
      .animate(target: isSelected ? 1 : 0)
      .scale(
        begin: const Offset(1, 1),
        end: const Offset(1.05, 1.05),
        duration: 300.ms,
        curve: Curves.easeOutQuad,
      ),
    );
  }
}
