import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:quiz_app/utils/app_theme.dart';

class AnimatedResultCard extends StatelessWidget {
  final int score;
  final int totalQuestions;
  final double percentage;
  final VoidCallback onTryAgain;
  final VoidCallback onBackToHome;

  const AnimatedResultCard({
    Key? key,
    required this.score,
    required this.totalQuestions,
    required this.percentage,
    required this.onTryAgain,
    required this.onBackToHome,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.accentColor,
              AppTheme.primaryLightColor.withOpacity(0.2),
            ],
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Score circle
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppTheme.primaryLightColor,
                    AppTheme.primaryColor,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 15,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '$score/$totalQuestions',
                      style: AppTheme.headingStyle.copyWith(
                        color: AppTheme.textLightColor,
                        fontSize: 36,
                      ),
                    ),
                    Text(
                      '${percentage.toInt()}%',
                      style: AppTheme.bodyStyle.copyWith(
                        color: AppTheme.textLightColor,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
            )
            .animate()
            .scale(
              begin: const Offset(0.5, 0.5),
              end: const Offset(1, 1),
              duration: 800.ms,
              curve: Curves.elasticOut,
            ),
            
            const SizedBox(height: 24),
            
            // Result message
            Text(
              _getResultMessage(percentage),
              style: AppTheme.headingStyle.copyWith(
                color: AppTheme.primaryColor,
                fontSize: 28,
              ),
              textAlign: TextAlign.center,
            )
            .animate()
            .fadeIn(delay: 300.ms, duration: 500.ms)
            .slideY(
              begin: 0.3,
              end: 0,
              delay: 300.ms,
              duration: 500.ms,
              curve: Curves.easeOutQuad,
            ),
            
            const SizedBox(height: 16),
            
            // Result description
            Text(
              _getResultDescription(percentage),
              style: AppTheme.bodyStyle.copyWith(
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            )
            .animate()
            .fadeIn(delay: 500.ms, duration: 500.ms),
            
            const SizedBox(height: 32),
            
            // Try again button
            ElevatedButton.icon(
              onPressed: onTryAgain,
              icon: const Icon(Icons.replay),
              label: const Text('Try Again'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            )
            .animate()
            .fadeIn(delay: 700.ms, duration: 500.ms)
            .slideY(
              begin: 0.3,
              end: 0,
              delay: 700.ms,
              duration: 500.ms,
              curve: Curves.easeOutQuad,
            ),
            
            const SizedBox(height: 16),
            
            // Back to home button
            TextButton.icon(
              onPressed: onBackToHome,
              icon: const Icon(Icons.home),
              label: const Text('Back to Home'),
            )
            .animate()
            .fadeIn(delay: 900.ms, duration: 500.ms),
          ],
        ),
      ),
    );
  }
  
  String _getResultMessage(double percentage) {
    if (percentage >= 90) {
      return 'Excellent!';
    } else if (percentage >= 70) {
      return 'Great Job!';
    } else if (percentage >= 50) {
      return 'Good Effort!';
    } else {
      return 'Keep Practicing!';
    }
  }
  
  String _getResultDescription(double percentage) {
    if (percentage >= 90) {
      return 'You\'re a quiz master! Your knowledge is impressive.';
    } else if (percentage >= 70) {
      return 'Well done! You have a good understanding of the topic.';
    } else if (percentage >= 50) {
      return 'Not bad! With a bit more practice, you\'ll improve your score.';
    } else {
      return 'Don\'t worry! Everyone starts somewhere. Keep learning and try again.';
    }
  }
}
